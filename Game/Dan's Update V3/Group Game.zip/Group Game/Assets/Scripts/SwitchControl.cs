﻿using UnityEngine;
using System.Collections;

public class SwitchControl : MonoBehaviour {

    public DoorControl MyDoor;
    private Rigidbody2D rb_;
    //MyDoor.active;
	// Use this for initialization
	void Start () {
        rb_ = gameObject.GetComponent<Rigidbody2D>();
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.gameObject.tag=="Player"|| collision.gameObject.tag == "Obstacle")
        {
            MyDoor.Active = false;
        }
    }

    private void OnCollisionStay2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Player" || collision.gameObject.tag == "Obstacle")
        {
            MyDoor.Active = true;
            
        }
    }

    private void OnCollisionEnter2D(Collider2D collision)
    {
        if(collision.gameObject.tag == "Trigger")
        {
            //rb_.constraints = RigidbodyConstraints2D.FreezeAll;


            rb_.constraints = RigidbodyConstraints2D.FreezePositionX | RigidbodyConstraints2D.FreezePositionY | RigidbodyConstraints2D.FreezeRotation;
        }
    }
}
