﻿//File Details
//Name:        Daniel Beales
//Student ID:  S185384
//Created:     21/02/2017
//Last Edited: 14/03/2017
//Last Editor: Daniel Beales
//File:        PhysicsController.cs


using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PhysicsController : MonoBehaviour {



    public GameObject obj;
    public Rigidbody2D rb_;
    public PhysicsMaterial2D mat;
    public KeyCode V;
    
    #region Transforms
    public Transform originaldirection;
    public Transform relecteddirection;
    private Transform direction;
    #endregion
    
    #region Material Stuff
    //material stuff
    public float Friction;
    public float Bounciness;
    public float Weight;
    Material Mater;
    PolygonCollider2D thiscol;
    PhysicMaterial coll;
    #endregion

    #region Keycode 
    public KeyCode addWeight;
    public KeyCode doubleBounce;
    #endregion

    public PhysicsMaterial2D PM;


    /// <summary>
    /// All need to be sorted into Regions. 
    /// </summary>
    public float gravityTimer;  //a timer for when gravity will shift.
    public float gravityTimerMultiplier; //a multiplier to manipulate the timer for the shifts. each level etc.

    public float player1GravityBar; //Their total amount of points they can minus, for gravity.
    public float player2GravityBar;

    [Range(1f, 10f)]
    public float player1GravityUseInt; //each players use of the gravity will minu this of their total.

    bool player1invoke = false;


    private float Currentplayer1GravityBar;//Whjere the bar is currently at the point of calling. Realtime.

    public GUISkin theSkin;


    // Use this for initialization
    void Start () {
        //material stuff
        thiscol = GetComponent<PolygonCollider2D>();
        PM = new PhysicsMaterial2D();
        PM.friction = Friction;
        PM.bounciness = Bounciness;
        thiscol.sharedMaterial = PM;
        rb_ = obj.GetComponent<Rigidbody2D>();
        rb_.mass = Weight;


        //Bar system
        player1GravityBar = 100;
        player2GravityBar = 100;

        Currentplayer1GravityBar = player1GravityBar;
	}

    void update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {

            player1GravityBar = player1GravityBar - player1GravityUseInt;
        }

        //if the gravity bar needs to start recharing
        if (player1GravityBar <= 100)
        {
            if (player1invoke == true) //if the recharge has started.
            {
                return;
            }
            else
            {
                player1invoke = true; //The recharge has stared
                StartCoroutine(AddTime1()); //Start the charge.
            }
        }
        else
        {
            //CancelInvoke("AddTime1");
            StopCoroutine(AddTime1()); //If the bar = 100 then stop the charging.
        }

        if (player1GravityBar >= player1GravityUseInt)
        {
            //Flip Gravity
        }


    }

    public void createGui()
    {

        //Create the bar, Was going to create just number for now, But we could create a loading bar like object. 
        string player1GravityBar = Currentplayer1GravityBar + "//";
        //Daniel's Code:
        GUI.skin = theSkin;
        GUI.Label(new Rect(Screen.width * 0.50f, Screen.height * (8 / 9), 30, 49), Currentplayer1GravityBar.ToString());

    }

    IEnumerator AddTime1()
    {
        //add an amount back onto the gravity bar per second
        yield return new WaitForSeconds(1);
        Currentplayer1GravityBar++;
    }
	
    void OnCollisionEnter(Collision collisionInfo)
    {
        //Here we want to when ever the object hits any sort of collider, we want it to bounce in the opposite direction, Tried using the addforce and reflect, could not get the direction bit working.

        Vector3 playerpos = this.transform.position;
        //relecteddirection.position = Vector3.Reflect(originaldirection.position, Vector3.right);
        
        //rb_.AddForce(Vector3.Reflect(direction, collisionInfo.contacts[0].normal * 5, ForceMode.Impulse));


    }


    void GravityOn() //when gravity is turned on, Normal
    {

    }

    void GravityOFF() //when Gravity is reveresed.
    {
        float change = 10f;
        if (Input.GetKeyDown(KeyCode.K))
        {            
            //Physics.gravity = Vector3(0, 10, 0);
            Physics.gravity.Set(0, 10, 0);
            //Physics.gravity += *change;

        }

    }

    float timeramount; //starter amount
    public float easyTimerAmount; //Easy dificulty stuff
    public float easyMultiplier; //easy dificulty multiplier
    public float mTimerMultiplier; //Medium Difficulty multipler




    void GravityTimers()
    {
        
        float TimerMultiplier; //How much to be multiplied
        float TimerLevel; //Easy, Medium, hard etc, Effects amount and multiplier
        float difficulty = 0; //0 easy, 1, 2 medium, 3 Hard, 4 Extreame.        
        
        if (difficulty == 0) //if diffuclty is easy
        {
            timeramount = easyTimerAmount;
        }
        else if (difficulty == 1)
        {
            TimerMultiplier = mTimerMultiplier;
            timeramount = timeramount * TimerMultiplier;
        }
        else if(difficulty == 2)
        {


        }else if(difficulty == 3)
        {


        }else if(difficulty == 4)
        {

        }

    }

    void GravityControls()
    {


    }

}
